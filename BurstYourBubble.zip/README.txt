Welcome to Burst Your Bubble. In order to play, press W to toggle shooting, A to move left, and D to move Right. 
Once the game boots up, press space to start. If you die, press space to restart.
The game is compiled by performing:
javac *.java
java Main
Enjoy